/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.model;

/**
 *
 * @author Familia Souza
 */
public class ProdutosPedido {
    private int idProduto;
    private int idPedido;
    private int qtde;
    
    public ProdutosPedido(int idProduto, int idPedido, int qtde) {
        this.idPedido = idPedido;
        this.idProduto = idProduto;
        this.qtde = qtde;
    }
    public int getIdPedido() {
        return this.idPedido;
    }
    public int getIdProduto() {
        return this.idProduto;
    }
    public int getQtde() {
        return this.qtde;
    }
    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }
    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }
    public void setQtde(int qtde) {
         this.qtde = qtde;
    }
}

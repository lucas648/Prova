/*
 * PROVA POO 1o SEM 2017 - ADS MANHÃ
 * Nelson Carvalho de Morais Junior
 * RA: 1430481521039
 */
package br.fatec.prova.model;

public class Produto {
    // Atributos
    private String nome;
    private double preco;
    private int qtdVendida;
    private int id;
    
    // Construtor
    public Produto(String nome, double preco){
        this.nome = nome;
        this.preco = preco;
        this.qtdVendida = 0;
    }
    public Produto(int id, String nome, double preco, int qtde){
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.qtdVendida = qtde;
    }
    
    // Getters
    public String getNome() {
        return this.nome;
    }
    public double getPreco() {
        return this.preco;
    }
    public int getQtdVendida() {
        return this.qtdVendida;
    }
    public int getId() {
        return this.id;
    }
    
    // Setters
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setPreco(double preco) {
        this.preco = preco;
    }
    public void setQtdVendida(int qtdVendida) {
        this.qtdVendida = qtdVendida;
    }
    public void setId(int id) {
        this.id = id;
    }
}
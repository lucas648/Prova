/*
 * PROVA POO 1o SEM 2017 - ADS MANHÃ
 * Nelson Carvalho de Morais Junior
 * RA: 1430481521039
 */
package br.fatec.prova.model;

import java.util.ArrayList;

public class Pedido {
    // Atributos
    private int idPedido;
    private String data;
    private double valorTotal;
    private Cliente cliente;
    private ArrayList<Produto> produtos;
    private int id;
    
    // Construtor
    public Pedido(int idPedido, String data, Cliente cliente, double valorTotal) {
        this.idPedido = idPedido;
        this.cliente = cliente;
        this.data = data;
        this.valorTotal = valorTotal;
        this.produtos = new ArrayList<>();
    }
    public Pedido(String data, double valorTotal) {
        this.data = data;
        this.valorTotal = valorTotal;
    }
    
    // Getters
    public int getIdPedido() {
        return this.idPedido;
    }
    public String getData() {
        return this.data;
    }
    public double getValorTotal() {
        return this.valorTotal;
    }
    public Cliente getCliente() {
        return this.cliente;
    }
    public ArrayList<Produto> getProdutos() {
        return this.produtos;
    }
    public int getId() {
        return this.id;
    }
    
    //Setters
    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }
    public void setData(String data) {
        this.data = data;
    }
    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public void setProdutos(ArrayList<Produto> produtos) {
        this.produtos = produtos;
    }
    public void setId(int id) {
        this.id = id;
    }
    
    // Adicionar produtos
    public void addProduto(Produto p, int quant) {
        // Adicionar atributos do pedido
        ArrayList<Produto> listaProd = getProdutos();
        listaProd.add(p);
        this.setValorTotal(this.getValorTotal() + (quant * p.getPreco()));
        // Adicionar dados do produto
        p.setQtdVendida(p.getQtdVendida() + quant);
        // Adicionar dados do cliente
        Cliente c = this.getCliente();
        c.setQtdProdComprados(c.getQtdProdComprados() + quant);
        c.setValorGasto(c.getValorGasto() + (quant * p.getPreco()));
    }
}
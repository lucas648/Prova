/*
 * PROVA POO 1o SEM 2017 - ADS MANHÃ
 * Nelson Carvalho de Morais Junior
 * RA: 1430481521039
 */
package br.fatec.prova.model;

public class Cliente {
    // Atributos
    private int id;
    private String nome;
    private String cpf;
    private double valorGasto;
    private int qtdProdComprados;
    
    // Construtor
    public Cliente(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
        this.valorGasto = this.qtdProdComprados = 0;
    }
    public Cliente(int id, String nome, String cpf, double valor, int qtde) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.valorGasto = valor;
        this.qtdProdComprados = qtde;
    }
    
    // Getters
    public String getNome() {
        return this.nome;
    }
    public String getCpf() {
        return this.cpf;
    }
    public double getValorGasto() {
        return this.valorGasto;
    }
    public int getQtdProdComprados() {
        return this.qtdProdComprados;
    }
    public int getId() {
        return this.id;
    }
    
    // Setters
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void setValorGasto(double valorGasto) {
        this.valorGasto = valorGasto;
    }
    public void setQtdProdComprados(int qtdProdComprados) {
        this.qtdProdComprados = qtdProdComprados;
    }
    public void setId(int id) {
        this.id = id;
    }
}
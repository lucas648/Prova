/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.dao;

import br.fatec.prova.model.Cliente;
import br.fatec.prova.model.Pedido;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lucascosta
 */
public class DaoPedido {
    public void insertpedido(Connection con, Pedido c, int idCliente) {
        try {
            // Query
            String query = "INSERT INTO Pedido(id_cliente, data, valor_total) VALUES " +
                    "(" + idCliente + ", '" + c.getData() + "', " + c.getValorTotal() + ")";
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Alterar Cliente
    public void updatePedido(Connection con, br.fatec.prova.model.Pedido c) {
        try {
            // Query
            String query = "UPDATE Pedido SET "
                    + "nome = '" + c.getIdPedido() + "', preco = '" + c.getData() + "'"
                    + "WHERE valorTotal = " + c.getValorTotal();
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Excluir Cliente
    public void deletePedido(Connection con, int id) {
        try {
            // Query
            String query = "DELETE FROM Pedido WHERE id_pedido = " + id;
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Buscar Cliente
    public String[] selectPedidoById(Connection con, int id) {
        try {
            //Query
            String query = "SELECT * FROM Pedido WHERE id_pedido = " + id;
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            rs.next();
            String retorno[] = new String[4];
            retorno[0] = rs.getString("id_pedido");
            retorno[1] = rs.getString("valor_total");
            retorno[2] = rs.getString("data");
            retorno[3] = rs.getString("id_cliente");
            
            s.close();
            return retorno;
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    // Pegar Clientes
    public ArrayList<Pedido> selectPedidos(Connection con) {
        try {
            //Query
            String query = "SELECT * FROM Pedido";
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            ArrayList<Pedido> retorno = new ArrayList<Pedido>();
            
            while(rs.next()) {
                int idPedido = rs.getInt("id_pedido");
                String data = rs.getString("data");
                double valorTotal = rs.getDouble("valor_total");
                
                DaoCliente daoCli = new DaoCliente();
                
                String[] cli = daoCli.selectClienteById(con, rs.getInt("id_cliente"));
                Cliente cliente = new Cliente(Integer.parseInt(cli[0]), cli[1], cli[2], Double.parseDouble(cli[4]), Integer.parseInt(cli[3]));
                
                Pedido cr = new Pedido(idPedido, data, cliente, valorTotal);
                cr.setId(idPedido);
                
                retorno.add(cr);
            }
            
            s.close();
            
            return retorno;
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public int selectIdUltimoPedido(Connection con) {
        try {
            //Query
            String query = "SELECT * FROM Pedido ORDER BY id_pedido DESC";
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            
            rs.next();
            int idPedido = rs.getInt("id_pedido");
            
            s.close();
            return idPedido;
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
}

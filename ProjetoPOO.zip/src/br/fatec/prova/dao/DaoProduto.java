/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.dao;


import br.fatec.prova.model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lucascosta
 */
public class DaoProduto {
    public void insertproduto(Connection con, Produto c) {
        try {
            // Query
            String query = "INSERT INTO Produto(nome, preco, qtde_vendida) VALUES " +
                    "('" + c.getNome() + "', " + c.getPreco() + ", " + c.getQtdVendida() + ")";
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Alterar Cliente
    public void updateProduto(Connection con, Produto c) {
        try {
            // Query
            String query = "UPDATE Produto SET "
                    + "nome = '" + c.getNome() + "', preco = " + c.getPreco() + ", "
                    + "qtde_vendida = " + c.getQtdVendida() + " "
                    + " WHERE id_produto = " + c.getId();
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Excluir Cliente
    public void deleteProduto(Connection con, int id) {
        try {
            // Query
            String query = "DELETE FROM Produto WHERE id_produto = " + id;
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Buscar Cliente
    public String[] selectProdutoById(Connection con, int id) {
        try {
            //Query
            String query = "SELECT * FROM Produto WHERE id_produto = " + id;
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            if(rs.next()) {
                String retorno[] = new String[4];
                retorno[0] = rs.getString("id_produto");
                retorno[1] = rs.getString("nome");
                retorno[2] = rs.getString("preco");
                retorno[3] = rs.getString("qtde_vendida");
            
                s.close();
                return retorno;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    // Pegar Clientes
    public ArrayList<Produto> selectProdutos(Connection con) {
        try {
            //Query
            String query = "SELECT * FROM Produto";
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            ArrayList<Produto> retorno = new ArrayList<Produto>();
            
            while(rs.next()) {
                int id = rs.getInt("id_produto");
                String nome = rs.getString("nome");
                Double preco = rs.getDouble("preco");
                int qtde = rs.getInt("qtde_vendida");
                Produto cr;
                cr = new Produto(id, nome, preco, qtde);
                
                retorno.add(cr);
            }
            
            s.close();
            
            return retorno;
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public ArrayList<Produto> selectProdMaisVend(Connection con) {
        try {
            //Query
            String query = "SELECT * FROM Produto ORDER BY qtde_vendida DESC FETCH FIRST 3 ROWS ONLY";
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            ArrayList<Produto> retorno = new ArrayList<Produto>();
            
            while(rs.next()) {
                int id = rs.getInt("id_produto");
                String nome = rs.getString("nome");
                Double preco = rs.getDouble("preco");
                int qtde = rs.getInt("qtde_vendida");
                Produto cr;
                cr = new Produto(id, nome, preco, qtde);
                
                retorno.add(cr);
            }
            
            s.close();
            
            return retorno;
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}

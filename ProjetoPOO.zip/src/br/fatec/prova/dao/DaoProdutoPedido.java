/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.dao;

import br.fatec.prova.model.ProdutosPedido;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoProdutoPedido {
    public void insertProdutoPedido(Connection con, int idPedido, int idProduto, int qtde) {
        try {
            // Query
            String query = "INSERT INTO ProdutosPedido(id_pedido, id_produto, qtde) VALUES " +
                    "(" + idPedido + ", " + idProduto + ", " + qtde + ")";
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Excluir
    public void deleteProdutosPedido(Connection con, int idPedido) {
        try {
            // Query
            String query = "DELETE FROM ProdutosPedido WHERE id_pedido = " + idPedido;
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Pegar Produtos Pedido
    public ArrayList<ProdutosPedido> selectProdutosPedido(Connection con, int id) {
        try {
            //Query
            String query = "SELECT * FROM ProdutosPedido WHERE id_pedido = " + id;
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            ArrayList<ProdutosPedido> retorno = new ArrayList<ProdutosPedido>();
            
            while(rs.next()) {
                int idPedido = rs.getInt("id_pedido");
                int idProduto = rs.getInt("id_produto");
                int qtde = rs.getInt("qtde");

                ProdutosPedido cr = new ProdutosPedido(idProduto, idPedido, qtde);
                
                retorno.add(cr);
            }
            
            s.close();
            
            return retorno;
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoProdutoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }    
}

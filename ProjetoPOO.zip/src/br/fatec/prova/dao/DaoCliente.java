package br.fatec.prova.dao;
import br.fatec.prova.model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoCliente {
    // Inserir Cliente
    public void insertCliente(Connection con, Cliente c) {
        try {
            // Query
            String query = "INSERT INTO Cliente(nome, cpf, qtde_comprada, valor_gasto) VALUES " +
                    "('" + c.getNome() + "', '" + c.getCpf() + "', 0, 0)";
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Alterar Cliente
    public void updateCliente(Connection con, Cliente c) {
        try {
            // Query
            String query = "UPDATE Cliente SET "
                    + "nome = '" + c.getNome() + "', cpf = '" + c.getCpf() + "', "
                    + "qtde_comprada = " + c.getQtdProdComprados() + ", valor_gasto = " + c.getValorGasto()
                    + " WHERE id_cliente = " + c.getId();
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Excluir Cliente
    public void deleteCliente(Connection con, int id) {
        try {
            // Query
            String query = "DELETE FROM Cliente WHERE id_cliente = " + id;
            // Executar Query
            PreparedStatement ps = con.prepareStatement(query);
            ps.execute();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Buscar Cliente
    public String[] selectClienteById(Connection con, int id) {
        try {
            //Query
            String query = "SELECT * FROM Cliente WHERE id_cliente = " + id;
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            rs.next();
            String retorno[] = new String[5];
            retorno[0] = rs.getString("id_cliente");
            retorno[1] = rs.getString("nome");
            retorno[2] = rs.getString("cpf");
            retorno[3] = rs.getString("qtde_comprada");
            retorno[4] = rs.getString("valor_gasto");
            
            s.close();
            return retorno;
        } catch (SQLException ex) {
            Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    // Pegar Clientes
    public ArrayList<Cliente> selectClientes(Connection con) {
        try {
            //Query
            String query = "SELECT * FROM Cliente";
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            ArrayList<Cliente> retorno = new ArrayList<Cliente>();
            
            while(rs.next()) {
                int id = rs.getInt("id_cliente");
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                int qtdeComprada = Integer.parseInt(rs.getString("qtde_comprada"));
                double valorGasto = Double.parseDouble(rs.getString("valor_gasto"));
                
                Cliente cr = new Cliente(id, nome, cpf, valorGasto, qtdeComprada);
                
                retorno.add(cr);
            }
            
            //retorno.remove(retorno.size() - 1);
            
            s.close();
            
            return retorno;
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public ArrayList<Cliente> selectCliMaiorValor(Connection con) {
        try {
            //Query
            String query = "SELECT * FROM Cliente ORDER BY valor_gasto DESC FETCH FIRST 3 ROWS ONLY";
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            ArrayList<Cliente> retorno = new ArrayList<Cliente>();
            
            while(rs.next()) {
                int id = rs.getInt("id_cliente");
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                int qtdeComprada = Integer.parseInt(rs.getString("qtde_comprada"));
                double valorGasto = Double.parseDouble(rs.getString("valor_gasto"));
                
                Cliente cr = new Cliente(id, nome, cpf, valorGasto, qtdeComprada);
                
                retorno.add(cr);
            }
            
            //retorno.remove(retorno.size() - 1);
            
            s.close();
            
            return retorno;
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public ArrayList<Cliente> selectCliMaiorQtde(Connection con) {
        try {
            //Query
            String query = "SELECT * FROM Cliente ORDER BY qtde_comprada DESC FETCH FIRST 3 ROWS ONLY";
            // Executar Query
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(query);
            // Criar Array de retorno
            ArrayList<Cliente> retorno = new ArrayList<Cliente>();
            
            while(rs.next()) {
                int id = rs.getInt("id_cliente");
                String nome = rs.getString("nome");
                String cpf = rs.getString("cpf");
                int qtdeComprada = Integer.parseInt(rs.getString("qtde_comprada"));
                double valorGasto = Double.parseDouble(rs.getString("valor_gasto"));
                
                Cliente cr = new Cliente(id, nome, cpf, valorGasto, qtdeComprada);
                
                retorno.add(cr);
            }
            
            //retorno.remove(retorno.size() - 1);
            
            s.close();
            
            return retorno;
            
        } catch (SQLException ex) {
            Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}

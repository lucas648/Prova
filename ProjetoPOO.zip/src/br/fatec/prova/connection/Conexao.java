package br.fatec.prova.connection;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lucascosta
 */
public class Conexao {
    public Connection criarbd(){
        String barra = File.separator;
        String projeto = System.getProperty("user.dir") + barra + "Registros";
        File url = new File(projeto);
        if (url.exists()){
            System.out.println("Bd Existe");
        }else{
            try {
                Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
                String db = "jdbc:derby:" +projeto+";create=true";
                try {
                    Connection con = DriverManager.getConnection(db);
                    String tabela1 ="CREATE TABLE Cliente(id_cliente INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY "
                            + "(START WITH 1, INCREMENT BY 1), nome VARCHAR(50), cpf VARCHAR(15), "
                            + "valor_gasto DECIMAL(5, 2), qtde_comprada INT)";
                    PreparedStatement ps1 = con.prepareStatement(tabela1) ;
                    ps1.execute();
                    ps1.close();
                    String tabela2 ="CREATE TABLE Produto(id_produto INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY"
                            + "(START WITH 1, INCREMENT BY 1), nome VARCHAR(50), preco DECIMAL(5, 2), qtde_vendida INT)";
                    PreparedStatement ps2 = con.prepareStatement(tabela2) ;
                    ps2.execute();
                    ps2.close();
                    String tabela3 ="CREATE TABLE Pedido(id_pedido INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY"
                            + "(START WITH 1, INCREMENT BY 1), valor_total DECIMAL(5, 2), data VARCHAR(15), id_cliente INT)";
                    PreparedStatement ps3 = con.prepareStatement(tabela3) ;
                    ps3.execute();
                    ps3.close();
                    String tabela4 ="CREATE TABLE ProdutosPedido(id_pedido INT, id_produto INT, qtde INT)";
                    PreparedStatement ps4 = con.prepareStatement(tabela4) ;
                    ps4.execute();
                    ps4.close();
                    System.out.println("Base de dados criada");
                    return con;
                } catch (SQLException ex) {
                    Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
                }
                        
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return null;
    }
    
    public Connection getConnection() {
        String barra = File.separator;
        String projeto = System.getProperty("user.dir") + barra + "Registros";
        File url = new File(projeto);
        if (!url.exists()){
            System.out.println("Bd Não Existe");
        }else{
            try {
                Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
                String db = "jdbc:derby:" +projeto+";";
                try {
                    return DriverManager.getConnection(db);
                } catch (SQLException ex) {
                    Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
                }
                        
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return null;
    }
}

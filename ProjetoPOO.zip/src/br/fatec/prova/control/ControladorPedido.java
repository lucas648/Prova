/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.control;

import br.fatec.prova.connection.Conexao;
import br.fatec.prova.dao.DaoPedido;
import br.fatec.prova.model.Pedido;
import java.util.ArrayList;

/**
 *
 * @author Familia Souza
 */
public class ControladorPedido {

    public int cadastrarPedido(String data, int idCliente, double valorTotal) {
        DaoPedido dao = new DaoPedido();
        Conexao con = new Conexao();
        dao.insertpedido(con.getConnection(), new Pedido(data, valorTotal), idCliente);
        return dao.selectIdUltimoPedido(con.getConnection());
    }

    public String[][] consultarPedidos() {
        
        ArrayList<Pedido> pedidos = new DaoPedido().selectPedidos(new Conexao().getConnection());
        String[][] retorno = new String[pedidos.size()][4];
        
        int i = 0;
        for(Pedido ped : pedidos) {
            retorno[i][0] = String.valueOf(ped.getId());
            retorno[i][1] = ped.getCliente().getNome();
            retorno[i][2] = ped.getData();
            retorno[i][3] = String.valueOf(ped.getValorTotal());
            i++;
        }
        return retorno;
    }

    public String[] consultarPedido(int idPedido) {
        return new DaoPedido().selectPedidoById(new Conexao().getConnection(), idPedido);
    }

    public void excluirPedido(int idPedido) {
        new DaoPedido().deletePedido(new Conexao().getConnection(), idPedido);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.control;

import br.fatec.prova.connection.Conexao;
import br.fatec.prova.dao.DaoProdutoPedido;
import br.fatec.prova.model.ProdutosPedido;
import java.util.ArrayList;

/**
 *
 * @author Familia Souza
 */
public class ControladorProdutosPedido {

    public void cadastrarProdutosPedido(int idPedido, int idProduto, int qtde) {
        new DaoProdutoPedido().insertProdutoPedido(new Conexao().getConnection(), idPedido, idProduto, qtde);
    }

    public int[][] cosultarProdutosPedido(int idPedido) {
        ArrayList<ProdutosPedido> prodPed = new DaoProdutoPedido().selectProdutosPedido(new Conexao().getConnection(), idPedido);
        int[][] retorno = new int[prodPed.size()][3];
        int i = 0;
        for(ProdutosPedido pp : prodPed) {
            retorno[i][0] =pp.getIdPedido();
            retorno[i][1] = pp.getIdProduto();
            retorno[i][2] = pp.getQtde();
            i++;
        }
        return retorno;
    }

    public void excluirProdutosPedido(int idPedido) {
        new DaoProdutoPedido().deleteProdutosPedido(new Conexao().getConnection(), idPedido);
    }
    
}

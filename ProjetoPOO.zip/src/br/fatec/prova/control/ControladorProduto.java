/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.control;

import br.fatec.prova.connection.Conexao;
import br.fatec.prova.dao.DaoProduto;
import br.fatec.prova.model.Produto;
import java.util.ArrayList;

/**
 *
 * @author Familia Souza
 */
public class ControladorProduto {

    public void cadastrarProduto(String nome, double preco) {
        new DaoProduto().insertproduto(new Conexao().getConnection(), new Produto(nome, preco));
    }
    
    public void editarProduto(int id, String nome, double preco, int qtde) {
        new DaoProduto().updateProduto(new Conexao().getConnection(), new Produto(id, nome, preco, qtde));
    }

    public String[][] consultarProdutos() {
        ArrayList<Produto> produtos = new DaoProduto().selectProdutos(new Conexao().getConnection());
        String[][] retorno = new String[produtos.size()][4];
        int i = 0;
        
        for(Produto produto : produtos) {
            retorno[i][0] = String.valueOf(produto.getId());
            retorno[i][1] = produto.getNome();
            retorno[i][2] = String.valueOf(produto.getPreco());
            retorno[i][3] = String.valueOf(produto.getQtdVendida());
            i++;
        }
        return retorno;
    }

    public void excluirProduto(int id) {
        new DaoProduto().deleteProduto(new Conexao().getConnection(), id);
    }

    public String[] consultarProduto(int idProduto) {
        return new DaoProduto().selectProdutoById(new Conexao().getConnection(), idProduto);
    }

    public String[][] consultarProdMaisVend() {
        ArrayList<Produto> produtos = new DaoProduto().selectProdMaisVend(new Conexao().getConnection());
        String[][] retorno = new String[produtos.size()][4];
        int i = 0;
        
        for(Produto produto : produtos) {
            retorno[i][0] = String.valueOf(produto.getId());
            retorno[i][1] = produto.getNome();
            retorno[i][2] = String.valueOf(produto.getPreco());
            retorno[i][3] = String.valueOf(produto.getQtdVendida());
            i++;
        }
        return retorno;
    }
    
}

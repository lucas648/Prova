/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.fatec.prova.control;

import br.fatec.prova.connection.Conexao;
import br.fatec.prova.dao.DaoCliente;
import br.fatec.prova.model.Cliente;
import java.util.ArrayList;

/**
 *
 * @author Familia Souza
 */
public class ControladorCliente {

    public void cadastrarCliente(String nome, String cpf) {
        new DaoCliente().insertCliente(new Conexao().getConnection(), new Cliente(nome, cpf));
    }

    public void editarCliente(int id, String nome, String cpf, int qtde, double valor) {
        new DaoCliente().updateCliente(new Conexao().getConnection(), new Cliente(id, nome, cpf, valor, qtde));
    }

    public String[][] consultarClientes() {
        ArrayList<Cliente> clientes = new DaoCliente().selectClientes(new Conexao().getConnection());
        String[][] retorno = new String[clientes.size()][5];
        
        int i = 0;
        for(Cliente cli : clientes) {
            retorno[i][0] = String.valueOf(cli.getId());
            retorno[i][1] = cli.getNome();
            retorno[i][2] = cli.getCpf();
            retorno[i][3] = String.valueOf(cli.getQtdProdComprados());
            retorno[i][4] = String.valueOf(cli.getValorGasto());
            i++;
        }
        
        return retorno;
    }

    public void excluirCliente(int id) {
        new DaoCliente().deleteCliente(new Conexao().getConnection(), id);
    }

    public String[] consultarCliente(int idCliente) {
        return new DaoCliente().selectClienteById(new Conexao().getConnection(), idCliente);
    }

    public String[][] consultarCliMaiorValor() {
        ArrayList<Cliente> clientes = new DaoCliente().selectCliMaiorValor(new Conexao().getConnection());
        String[][] retorno = new String[clientes.size()][5];
        
        int i = 0;
        for(Cliente cli : clientes) {
            retorno[i][0] = String.valueOf(cli.getId());
            retorno[i][1] = cli.getNome();
            retorno[i][2] = cli.getCpf();
            retorno[i][3] = String.valueOf(cli.getQtdProdComprados());
            retorno[i][4] = String.valueOf(cli.getValorGasto());
            i++;
        }
        
        return retorno;
    }

    public String[][] consultarCliMaiorQtde() {
        ArrayList<Cliente> clientes = new DaoCliente().selectCliMaiorQtde(new Conexao().getConnection());
        String[][] retorno = new String[clientes.size()][5];
        
        int i = 0;
        for(Cliente cli : clientes) {
            retorno[i][0] = String.valueOf(cli.getId());
            retorno[i][1] = cli.getNome();
            retorno[i][2] = cli.getCpf();
            retorno[i][3] = String.valueOf(cli.getQtdProdComprados());
            retorno[i][4] = String.valueOf(cli.getValorGasto());
            i++;
        }
        
        return retorno;
    }
}
